# server-link-saver

## config.json

Add external url to config.json

"url": "ADD_EXTERNAL_URL"

## .env

### Auth0

AUTH0_DOMAIN=
AUTH0_SECRET=
AUTH0_AUDIENCE=

### Render

DATABASE_URL=

### Link client hosted upon

CLIENT_URL=

## sequelize

Proper after db setup

```bash
npm install --save-dev sequelize-cli
npx sequelize-cli db:migrate
```